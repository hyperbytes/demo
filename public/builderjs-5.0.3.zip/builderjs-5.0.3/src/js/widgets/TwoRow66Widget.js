class TwoRow66Widget extends Widget {
    getHtmlId() {
        return "TwoRow66Widget";
    }
}

window.TwoRow66Widget = TwoRow66Widget;