// IP field widget
class IpFieldWidget extends FieldWidget {
    getHtmlId() {
        return "IpFieldWidget";
    }
}

window.IpFieldWidget = IpFieldWidget;