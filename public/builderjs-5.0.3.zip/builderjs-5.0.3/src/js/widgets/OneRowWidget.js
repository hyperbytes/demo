// 1 row
class OneRowWidget extends Widget {
    getHtmlId() {
        return "OneRowWidget";
    }
}

window.OneRowWidget = OneRowWidget;