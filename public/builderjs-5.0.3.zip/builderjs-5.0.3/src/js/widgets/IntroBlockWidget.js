// Intro Block
class IntroBlockWidget extends Widget {
    getHtmlId() {
        return "IntroBlockWidget";
    }
}

window.IntroBlockWidget = IntroBlockWidget;