// Datetime field widget
class DatetimeFieldWidget extends FieldWidget {
    getHtmlId() {
        return "DatetimeFieldWidget";
    }
}

window.DatetimeFieldWidget = DatetimeFieldWidget;