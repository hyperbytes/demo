class TwoRow84Widget extends Widget {
    getHtmlId() {
        return "TwoRow84Widget";
    }
}

window.TwoRow84Widget = TwoRow84Widget;