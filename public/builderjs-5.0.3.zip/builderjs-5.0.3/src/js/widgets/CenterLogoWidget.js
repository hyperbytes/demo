// Center Logo
class CenterLogoWidget extends Widget {
    getHtmlId() {
        return "CenterLogoWidget";
    }
}
window.CenterLogoWidget = CenterLogoWidget;