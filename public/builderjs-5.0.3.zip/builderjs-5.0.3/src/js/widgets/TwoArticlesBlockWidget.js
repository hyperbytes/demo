// Two articles block
class TwoArticlesBlockWidget extends Widget {
    getHtmlId() {
        return "TwoArticlesBlockWidget";
    }
}

window.TwoArticlesBlockWidget = TwoArticlesBlockWidget;