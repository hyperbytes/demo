// Submit Button widget
class SubmitButtonWidget extends Widget {
    getHtmlId() {
        return "SubmitButtonWidget";
    }
}

window.SubmitButtonWidget = SubmitButtonWidget;