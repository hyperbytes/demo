class NoneElement extends SuperElement {
    getControls() {
        return [
        ];
    }
}

window.NoneElement = NoneElement;