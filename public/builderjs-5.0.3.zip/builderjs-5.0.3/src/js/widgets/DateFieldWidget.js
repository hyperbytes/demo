// Date field widget
class DateFieldWidget extends FieldWidget {
    getHtmlId() {
        return "DateFieldWidget";
    }
}

window.DateFieldWidget = DateFieldWidget;