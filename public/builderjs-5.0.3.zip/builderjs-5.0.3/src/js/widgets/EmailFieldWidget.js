// Email field widget
class EmailFieldWidget extends FieldWidget {
    getHtmlId() {
        return "EmailFieldWidget";
    }
}

window.EmailFieldWidget = EmailFieldWidget;