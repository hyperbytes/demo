class TextareaFieldWidget extends FieldWidget {
    getHtmlId() {
        return "TextareaFieldWidget";
    }
}

window.TextareaFieldWidget = TextareaFieldWidget;