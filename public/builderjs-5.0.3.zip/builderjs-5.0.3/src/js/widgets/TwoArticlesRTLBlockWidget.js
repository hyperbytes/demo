// Two articles RTL block
class TwoArticlesRTLBlockWidget extends Widget {
    getHtmlId() {
        return "TwoArticlesRTLBlockWidget";
    }
}

window.TwoArticlesRTLBlockWidget = TwoArticlesRTLBlockWidget;