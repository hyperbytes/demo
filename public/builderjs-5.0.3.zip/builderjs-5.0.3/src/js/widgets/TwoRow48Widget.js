class TwoRow48Widget extends Widget {
    getHtmlId() {
        return "TwoRow48Widget";
    }
}

window.TwoRow48Widget = TwoRow48Widget;