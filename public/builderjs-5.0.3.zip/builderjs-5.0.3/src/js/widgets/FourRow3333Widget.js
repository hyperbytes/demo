class FourRow3333Widget extends Widget {
    getHtmlId() {
        return "FourRow3333Widget";
    }
}

window.FourRow3333Widget = FourRow3333Widget;