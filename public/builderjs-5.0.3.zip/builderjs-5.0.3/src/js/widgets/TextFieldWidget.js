// Text field widget
class TextFieldWidget extends FieldWidget {
    getHtmlId() {
        return "TextFieldWidget";
    }
}

window.TextFieldWidget = TextFieldWidget;