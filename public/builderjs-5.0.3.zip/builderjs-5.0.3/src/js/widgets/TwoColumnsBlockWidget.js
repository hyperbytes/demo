// Two columns block
class TwoColumnsBlockWidget extends Widget {
    getHtmlId() {
        return "TwoColumnsBlockWidget";
    }
}

window.TwoColumnsBlockWidget = TwoColumnsBlockWidget;