// Header Block
class HeaderBlockWidget extends Widget {
    getHtmlId() {
        return "HeaderBlockWidget";
    }
}

window.HeaderBlockWidget = HeaderBlockWidget;