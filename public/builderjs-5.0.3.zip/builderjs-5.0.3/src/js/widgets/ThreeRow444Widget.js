class ThreeRow444Widget extends Widget {
    getHtmlId() {
        return "ThreeRow444Widget";
    }
}

window.ThreeRow444Widget = ThreeRow444Widget;