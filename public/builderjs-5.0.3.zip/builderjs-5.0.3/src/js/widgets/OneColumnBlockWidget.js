// One columns block
class OneColumnBlockWidget extends Widget {
    getHtmlId() {
        return "OneColumnBlockWidget";
    }
}

window.OneColumnBlockWidget = OneColumnBlockWidget;