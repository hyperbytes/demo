// Social links
class SocialLinksBlockWidget extends Widget {
    getHtmlId() {
        return "SocialLinksBlockWidget";
    }
}

window.SocialLinksBlockWidget = SocialLinksBlockWidget;