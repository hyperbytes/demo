// Two Footer
class FooterBlockWidget extends Widget {
    getHtmlId() {
        return "FooterBlockWidget";
    }
}

window.FooterBlockWidget = FooterBlockWidget;