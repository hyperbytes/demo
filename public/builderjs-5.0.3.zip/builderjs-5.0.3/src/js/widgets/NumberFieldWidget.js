// Number field widget
class NumberFieldWidget extends FieldWidget {
    getHtmlId() {
        return "NumberFieldWidget";
    }
}

window.NumberFieldWidget = NumberFieldWidget;