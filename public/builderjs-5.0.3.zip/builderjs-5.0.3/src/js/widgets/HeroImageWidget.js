// Hero Image
class HeroImageWidget extends Widget {
    getHtmlId() {
        return "HeroImageWidget";
    }
}

window.HeroImageWidget = HeroImageWidget;