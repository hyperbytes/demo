// Three columns block
class ThreeColumnsBlockWidget extends Widget {
    getHtmlId() {
        return "ThreeColumnsBlockWidget";
    }
}

window.ThreeColumnsBlockWidget = ThreeColumnsBlockWidget;